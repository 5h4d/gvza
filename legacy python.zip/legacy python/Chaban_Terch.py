import tkinter
canvas = tkinter.Canvas(height=500, width=500)
canvas.pack()
canvas.configure(background='black')
canvas.create_oval(0, 0, 500, 500, fill='red')
#kruh1
canvas.create_oval(25, 25, 475, 475, fill='white')
#kruh2
canvas.create_oval(50, 50, 450, 450, fill='red')
#kruh3
canvas.create_oval(75, 75, 425, 425, fill='white')
#kruh4
canvas.create_oval(100, 100, 400, 400, fill='red')
#kruh5
canvas.create_oval(125, 125, 375, 375, fill='white')
#kruh6
canvas.create_oval(150, 150, 350, 350, fill='red')
#kruh7
canvas.create_oval(175, 175, 325, 325, fill='white')
#kruh8
canvas.create_oval(200, 200, 300, 300, fill='red')
#kruh9
canvas.create_oval(225, 225, 275, 275, fill='white')
#kruh10
